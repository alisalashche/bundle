import { Grid } from '@/components/general-styled-components/layout/layout-block';
import { Screen } from '@/components/general-styled-components/layout/screen';
import { BundleRow } from '@/components/general-styled-components/navigation/bundle-preview';
import { Muted, Title } from '@/components/general-styled-components/typography';
import { ProjectSection } from '@/components/projects/project-section';
import { useProjectStore } from '@/hooks/use-project-store';
import { useYarnStore } from '@/hooks/use-yarn-store';
import { groupByMonth } from '@/utils/dates';
import { getCover } from '@/utils/project';
import { router } from 'expo-router';
import styled from 'styled-components/native';

const Section = styled.View`
  gap: 12px;
  margin-top: 8px;
`;

const Rows = styled.View`
  gap: 15px;
`;

const CenteredMuted = styled(Muted)`
  text-align: center;
  padding: 20px 60px;
`;

export default function HomeScreen() {
  const projects = useProjectStore((state) => state.projects);
  const yarns = useYarnStore((state) => state.yarns);

  const active = projects.filter((project) => project.status === 'active');
  const available = yarns.filter((yarn) => !yarn.archived);
  const finished = projects
    .filter((project) => project.status === 'finished' && project.finishedAt)
    .sort((a, b) => b.finishedAt!.localeCompare(a.finishedAt!));

  return (
    <Screen>
      <Section>
        <Title>My bundle</Title>
        <Rows>
          <BundleRow
            title="Projects"
            subtitle={`${active.length} WIP`}
            photos={active.map((project) => getCover(project))}
            onPress={() => router.push('/projects')}
          />
          <BundleRow
            title="Yarn collection"
            subtitle={`${available.length} yarn types`}
            photos={available.map((yarn) => yarn.photoUri)}
            onPress={() => router.push('/yarn')}
          />
        </Rows>
      </Section>

      <Section>
        <Title>Inspiration</Title>
        <CenteredMuted>Try to save pictures, tutorials, and patterns</CenteredMuted>
      </Section>

      <Section>
        <Title>Admire your works</Title>
        {finished.length === 0 ? (
          <CenteredMuted>Complete your first work</CenteredMuted>
        ) : (
          <Grid>
            {/* <PhotoTile
                key={project.id}
                uri={getCover(project)}
                label={project.name}
                onPress={() => router.push(`/projects/${project.id}`)}
              /> */}
            <ProjectSection
              title="Admire your works"
              groups={groupByMonth(finished, (project) => project.finishedAt!)}
            />
          </Grid>
        )}
      </Section>
    </Screen>
  );
}