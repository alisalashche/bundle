import { EmptyState } from '@/components/empty-state';
import { AddButton } from '@/components/general-styled-components/buttons/add-button';
import { YarnCard } from '@/components/general-styled-components/layout/cards/yarn-card';
import { Grid } from '@/components/general-styled-components/layout/layout-block';
import { Screen } from '@/components/general-styled-components/layout/screen';
import { Breadcrumbs } from '@/components/general-styled-components/navigation/breadcrumbs';
import { LinkRow } from '@/components/general-styled-components/navigation/grey-button';
import { Heading } from '@/components/general-styled-components/typography';
import { PageHeader } from '@/components/page-header';
import { useYarnStore } from '@/hooks/use-yarn-store';
import { router } from 'expo-router';

export default function YarnScreen() {
    const yarns = useYarnStore((state) => state.yarns);
    const available = yarns.filter((yarn) => !yarn.archived);
    const addYarn = () => router.push('/yarn/new');

    return (
        <Screen>
            <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Yarn' }]} />
            <PageHeader title="Yarn collection" description="Keep track of all yarns in your yarn stash" />

            {available.length === 0 ? (
                <EmptyState heading="Your stash is empty" actionLabel="Add yarn" onAction={addYarn} />
            ) : (
                <>
                    <AddButton label="Add new yarn" onPress={addYarn} />
                    <Heading>Available yarn</Heading>
                    <Grid>
                        {available.map((yarn) => (
                            <YarnCard key={yarn.id} yarn={yarn} onPress={() => router.push(`/yarn/${yarn.id}`)} />
                        ))}
                    </Grid>
                </>
            )}

            <LinkRow label="See yarn archive →" onPress={() => router.push('/yarn/archive')} />
        </Screen>
    );
}