import { EmptyState } from '@/components/empty-state';
import { Screen } from '@/components/general-styled-components/layout/screen';
import { Breadcrumbs } from '@/components/general-styled-components/navigation/breadcrumbs';
import { PageHeader } from '@/components/page-header';
import { ProjectSection } from '@/components/projects/project-section';
import { openNewProject } from '@/hooks/use-project-draft-store';
import { useProjectStore } from '@/hooks/use-project-store';
import { groupByMonth } from '@/utils/dates';

export default function ProjectsScreen() {
  const projects = useProjectStore((state) => state.projects);
  const active = projects.filter((project) => project.status === 'active');
  const finished = projects
    .filter((project) => project.status === 'finished' && project.finishedAt)
    .sort((a, b) => b.finishedAt!.localeCompare(a.finishedAt!));

  return (
    <Screen>
      <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Projects' }]} />
      <PageHeader title="Projects" description="Keep track of all project’s materials and progress" />

      {projects.length === 0 ? (
        <EmptyState
          heading="No projects yet"
          text="Plan your first make: pick yarn, add steps and track your progress."
          actionLabel="New project"
          onAction={openNewProject}
        />
      ) : (
        <>
          {active.length > 0 && (
            <ProjectSection
              title={`Works in progress  x${active.length}`}
              groups={groupByMonth(active, (project) => project.createdAt)}
            />
          )}
          {finished.length > 0 && (
            <ProjectSection
              title="Admire your works"
              groups={groupByMonth(finished, (project) => project.finishedAt!)}
            />
          )}
        </>
      )}
    </Screen>
  );
}