import { DetailsStep } from '@/components/projects/add-project-wizard/step1-details';
import { YarnStep } from '@/components/projects/add-project-wizard/yarn-step'
import { StepsStep } from '@/components/projects/add-project-wizard/steps-step';
import { MaterialsStep } from '@/components/projects/add-project-wizard/materials-step';

import { useProjectDraftStore } from '@/hooks/use-project-draft-store';

export default function NewProjectScreen() {
    const step = useProjectDraftStore((state) => state.step);

    if (step === 1) return <DetailsStep />;
    if (step === 2) return <YarnStep />;
    if (step === 3) return <StepsStep />;
    return <MaterialsStep />;
}