import { Button } from '@/components/general-styled-components/buttons/button';
import { PhotoOption } from '@/components/general-styled-components/buttons/photo-button';
import { FieldGroup } from '@/components/general-styled-components/layout/layout-block';
import { Screen } from '@/components/general-styled-components/layout/screen';
import { BackLink } from '@/components/general-styled-components/navigation/back-button';
import { CenteredTitle, Label, Muted } from '@/components/general-styled-components/typography';
import { StepIndicator } from '@/components/general-styled-components/wizard/wizard-progress';
import { TextField } from '@/components/text-field';
import { useProjectDraftStore } from '@/hooks/use-project-draft-store';
import { useProjectStore } from '@/hooks/use-project-store';
import { pickPhotos } from '@/utils/images';
import { Image } from 'expo-image';
import { router } from 'expo-router';
import styled from 'styled-components/native';

const CenteredMuted = styled(Muted)`
  text-align: center;
`;

const Thumbs = styled.View`
  flex-direction: row;
  flex-wrap: wrap;
  gap: 6px;
`;

const Thumb = styled(Image)`
  width: 70px;
  height: 70px;
  border-radius: ${({ theme }) => theme.radius.xs}px;
`;

export function MaterialsStep() {
    const draft = useProjectDraftStore((state) => state.draft);
    const setField = useProjectDraftStore((state) => state.setField);
    const goTo = useProjectDraftStore((state) => state.goTo);
    const addProject = useProjectStore((state) => state.addProject);

    const addPhotos = async () => {
        const uris = await pickPhotos();
        if (uris.length) setField('referencePhotos', [...draft.referencePhotos, ...uris]);
    };

    const save = () => {
        const id = addProject({
            name: draft.name.trim(),
            craft: draft.craft,
            difficulty: draft.difficulty,
            yarnNeeded: Number(draft.yarnNeeded),
            hookNeedleSize: draft.hookNeedleSize || undefined,
            stitches: draft.stitches || undefined,
            tutorialUrl: draft.tutorialUrl || undefined,
            yarnIds: draft.yarnIds,
            steps: draft.steps,
            notes: draft.notes.trim() || undefined,
            referencePhotos: draft.referencePhotos,
        });
        router.back(); // close the wizard
        router.push(`/projects/${id}`); // open the new project
    };

    return (
        <Screen footer={<Button label="Add project" onPress={save} />}>
            <BackLink onPress={() => goTo(3)} />
            <StepIndicator current={4} total={4} />
            <CenteredTitle>Add additional materials</CenteredTitle>
            <CenteredMuted>Add your pattern, tutorials, references, notes, list of extra materials etc.</CenteredMuted>

            <TextField
                label="Notes"
                multiline
                style={{ minHeight: 93, textAlignVertical: 'top' }}
                value={draft.notes}
                onChangeText={(value) => setField('notes', value)}
            />

            <FieldGroup>
                <Label>Photos (Optional)</Label>
                <PhotoOption icon="folder.fill" label="Attach photo from library" height={64} onPress={addPhotos} />
            </FieldGroup>

            {draft.referencePhotos.length > 0 && (
                <Thumbs>
                    {draft.referencePhotos.map((uri) => (
                        <Thumb key={uri} source={{ uri }} contentFit="cover" />
                    ))}
                </Thumbs>
            )}
        </Screen>
    );
}