import { Button } from '@/components/general-styled-components/buttons/button';
import { YarnCard } from '@/components/general-styled-components/layout/cards/yarn-card';
import { GridSmall } from '@/components/general-styled-components/layout/layout-block';
import { Screen } from '@/components/general-styled-components/layout/screen';
import { BackButton } from '@/components/general-styled-components/navigation/back-button';
import { LinkRow } from '@/components/general-styled-components/navigation/grey-button';
import { CenteredTitle, Muted } from '@/components/general-styled-components/typography';
import { StepIndicator } from '@/components/general-styled-components/wizard/wizard-progress';
import { useProjectDraftStore } from '@/hooks/use-project-draft-store';
import { useYarnStore } from '@/hooks/use-yarn-store';
import { router } from 'expo-router';
import { SymbolView } from 'expo-symbols';
import styled, { useTheme } from 'styled-components/native';

const CenteredMuted = styled(Muted)`
  text-align: center;
`;

export function YarnStep() {
    const theme = useTheme();
    const yarns = useYarnStore((state) => state.yarns);
    const yarnIds = useProjectDraftStore((state) => state.draft.yarnIds);
    const toggleYarn = useProjectDraftStore((state) => state.toggleYarn);
    const goTo = useProjectDraftStore((state) => state.goTo);
    const available = yarns.filter((yarn) => !yarn.archived);

    return (
        <Screen footer={<Button label="Next" align="flex-end" onPress={() => goTo(3)} />}>
            <BackLink onPress={() => goTo(1)} />
            <StepIndicator current={2} total={4} />
            <CenteredTitle>Assign yarn</CenteredTitle>
            <CenteredMuted>Add or assign from available yarns.</CenteredMuted>

            {available.length === 0 ? (
                <CenteredMuted>Your stash is empty. Add your first yarn below.</CenteredMuted>
            ) : (
                <Grid>
                    {available.map((yarn) => {
                        const selected = yarnIds.includes(yarn.id);
                        return (
                            <YarnCard
                                key={yarn.id}
                                yarn={yarn}
                                selected={selected}
                                onPress={() => toggleYarn(yarn.id)}
                                corner={
                                    selected ? (
                                        <SymbolView name="checkmark.circle.fill" size={20} tintColor={theme.colors.white} />
                                    ) : undefined
                                }
                            />
                        );
                    })}
                </Grid>
            )}

            <LinkRow label="Add new yarn →" onPress={() => router.push('/projects/new-yarn')} />
        </Screen>
    );
}